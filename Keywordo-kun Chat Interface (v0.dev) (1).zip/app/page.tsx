"use client"

import { MinimalChatInterface } from "@/components/features/chat/minimal-chat-interface"

export default function ArticolloChatPage() {
  return (
    <div className="h-screen w-full bg-background">
      <MinimalChatInterface />
    </div>
  )
}
